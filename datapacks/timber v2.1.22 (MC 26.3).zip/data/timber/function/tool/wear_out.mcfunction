# wear out tool
execute store result storage timber:temp durability int 1 run scoreboard players get durability timber
function timber:tool/wear_out_macro with storage timber:temp
