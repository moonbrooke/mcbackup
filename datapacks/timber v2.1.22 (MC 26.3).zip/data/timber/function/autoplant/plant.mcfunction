# replace item-sapling with block-sapling
summon minecraft:falling_block ~ ~ ~ {BlockState:{id:"minecraft:barrier"},Time:1,DropItem:0b,Tags:["timber_item_to_block"]}
# Replace the whole state: 26.3 can serialize default block states as a string.
data modify entity @e[type=minecraft:falling_block,tag=timber_item_to_block,distance=...1,sort=arbitrary,limit=1] BlockState set from entity @s Item.id

item modify entity @s contents {type:"minecraft:set_count",count:-1,add:true}

# sapling will be checked every time
tag @s remove timber_checked
